Slop Evader

A browser add-on that searches the web before the first public release of ChatGPT, November 30th, 2022.
